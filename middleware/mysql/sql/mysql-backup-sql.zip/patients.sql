#create
CREATE TABLE `ismi`.`patients` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`name` VARCHAR(64) NOT NULL,
`birthdate` DATETIME NOT NULL,
`phone` VARCHAR(16) NOT NULL,
`id_gender` INT UNSIGNED NOT NULL,
`weight` FLOAT NULL,
`height` FLOAT NULL,
`id_disability` INT UNSIGNED NOT NULL,
PRIMARY KEY (`id`),
UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE,
UNIQUE INDEX `phone_UNIQUE` (`phone` ASC) VISIBLE,
INDEX `id_gender_idx` (`id_gender` ASC) VISIBLE,
INDEX `id_disability_idx` (`id_disability` ASC) VISIBLE,
CONSTRAINT `id_gender`
FOREIGN KEY (`id_gender`)
REFERENCES `ismi`.`gender_types` (`id`)
ON DELETE NO ACTION
ON UPDATE NO ACTION,
CONSTRAINT `id_disability`
FOREIGN KEY (`id_disability`)
REFERENCES `ismi`.`disability_types` (`id`)
ON DELETE NO ACTION
ON UPDATE NO ACTION);

#insert
INSERT INTO `ismi`.`patients`
(`name`, `birthdate`, `phone`, `id_gender`, `weight`, `height`, `id_disability`)
VALUES
(%s, %s, %s, %s, %s, %s, %s);
#update
UPDATE `ismi`.`patients`
SET
`name` = %s,
`birthdate` = %s,
`phone` = %s,
`id_gender` = %s,
`weight` = %s,
`height` = %s,
`id_disability` = %s
WHERE `id` = %s;
#delete
DELETE FROM `ismi`.`patients`
WHERE `id`=%s;
#select_all
SELECT `patients`.`id`,
    `patients`.`name`,
    `patients`.`birthdate`,
    `patients`.`phone`,
    `gender_types`.`type`,
    `patients`.`weight`,
    `patients`.`height`,
    `disability_types`.`type`
FROM `ismi`.`patients`, `ismi`.`gender_types`, `ismi`.`disability_types`
WHERE `patients`.`id_gender` = `gender_types`.`id` AND `patients`.`id_disability` = `disability_types`.`id`;
#find_by_name
SELECT `patients`.`id`,
    `patients`.`name`,
    `patients`.`birthdate`,
    `patients`.`phone`,
    `gender_types`.`type`,
    `patients`.`weight`,
    `patients`.`height`,
    `disability_types`.`type`
FROM `ismi`.`patients`, `ismi`.`gender_types`, `ismi`.`disability_types`
WHERE `patients`.`name` LIKE %s AND `patients`.`id_gender` = `gender_types`.`id` AND `patients`.`id_disability` = `disability_types`.`id`;
#find_by_id
SELECT `patients`.`id`,
    `patients`.`name`,
    `patients`.`birthdate`,
    `patients`.`phone`,
    `gender_types`.`type`,
    `patients`.`weight`,
    `patients`.`height`,
    `disability_types`.`type`
FROM `ismi`.`patients`, `ismi`.`gender_types`, `ismi`.`disability_types`
WHERE `patients`.`id` = %s AND `patients`.`id_gender` = `gender_types`.`id` AND `patients`.`id_disability` = `disability_types`.`id`;

#find_by_name_name_bd_phone
SELECT `patients`.`name`,
    `patients`.`birthdate`,
    `patients`.`phone`
FROM `ismi`.`patients`
WHERE `patients`.`name` LIKE %s;

#select_name_bd_phone
SELECT `patients`.`name`,
    `patients`.`birthdate`,
    `patients`.`phone`
FROM `ismi`.`patients`;
