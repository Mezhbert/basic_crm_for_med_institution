#create
CREATE TABLE `ismi`.`redirects` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`id_patient` INT UNSIGNED NOT NULL,
`id_doctor_from` INT UNSIGNED NOT NULL,
`reason` VARCHAR(64) NULL,
`id_doctor_to` INT UNSIGNED NOT NULL,
`date` DATETIME NOT NULL,
`diagnosis` VARCHAR(64) NULL,
`id_prescribed_medication` INT UNSIGNED NOT NULL,
PRIMARY KEY (`id`),
UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE,
INDEX `redirects_patient_id_idx` (`id_patient` ASC) VISIBLE,
INDEX `redirects_doctor_from_id_idx` (`id_doctor_from` ASC) VISIBLE,
INDEX `redirects_doctor_to_id_idx` (`id_doctor_to` ASC) VISIBLE,
INDEX `redirects_medication_id_idx` (`id_prescribed_medication` ASC) VISIBLE,
CONSTRAINT `redirects_patient_id`
FOREIGN KEY (`id_patient`)
REFERENCES `ismi`.`patients` (`id`)
ON DELETE NO ACTION
ON UPDATE NO ACTION,
CONSTRAINT `redirects_doctor_from_id`
FOREIGN KEY (`id_doctor_from`)
REFERENCES `ismi`.`doctors` (`id`)
ON DELETE NO ACTION
ON UPDATE NO ACTION,
CONSTRAINT `redirects_doctor_to_id`
FOREIGN KEY (`id_doctor_to`)
REFERENCES `ismi`.`doctors` (`id`)
ON DELETE NO ACTION
ON UPDATE NO ACTION,
CONSTRAINT `redirects_medication_id`
FOREIGN KEY (`id_prescribed_medication`)
REFERENCES `ismi`.`medications` (`id`)
ON DELETE NO ACTION
ON UPDATE NO ACTION);

#insert
INSERT INTO `ismi`.`redirects`
(`id_patient`, `id_doctor_from`, `reason`, `id_doctor_to`, `date`, `diagnosis`, `id_prescribed_medication`)
VALUES (%s, %s, %s, %s, %s, %s, %s);

#update
UPDATE `ismi`.`redirects`
SET
`id_patient` = %s,
`id_doctor_from` = %s,
`reason` = %s,
`id_doctor_to` = %s,
`date` = %s,
`diagnosis` = %s,
`id_prescribed_medication` = %s
WHERE `id` = %s;

#delete
DELETE FROM `ismi`.`redirects`
WHERE %s;

#select_all
SELECT `redirects`.`id`,
`redirects`.`id_patient`,
`redirects`.`id_doctor_from`,
`redirects`.`reason`,
`redirects`.`id_doctor_to`,
`redirects`.`date`,
`redirects`.`diagnosis`,
`redirects`.`id_prescribed_medication`
FROM `ismi`.`redirects`;

#select_with_names
SELECT `redirects`.`id`,
`patients`.`name`,
`doctors`.`name`,
`redirects`.`reason`,
`doctors`.`name`,
`redirects`.`date`,
`redirects`.`diagnosis`,
`medications`.`title`
FROM `ismi`.`redirects`, `ismi`.`patients`, `ismi`.`doctors`, `ismi`.`medications`
WHERE `redirects`.`id_patient` = `patients`.`id` AND `redirects`.`id_doctor_from` = `doctors`.`id` AND `redirects`.`id_doctor_to` = `doctors`.`id` AND `redirects`.`id_prescribed_medication` = `medications`.`id`;

#find_by_name_with_names
SELECT `redirects`.`id`,
`patients`.`name`,
`doctors`.`name`,
`redirects`.`reason`,
`doctors`.`name`,
`redirects`.`date`,
`redirects`.`diagnosis`,
`medications`.`title`
FROM `ismi`.`redirects`, `ismi`.`patients`, `ismi`.`doctors`, `ismi`.`medications`
WHERE `patients`.`name` LIKE %s AND `redirects`.`id_patient` = `patients`.`id` AND `redirects`.`id_doctor_from` = `doctors`.`id` AND `redirects`.`id_doctor_to` = `doctors`.`id` AND `redirects`.`id_prescribed_medication` = `medications`.`id`;
