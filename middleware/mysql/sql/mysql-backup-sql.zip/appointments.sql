#create
CREATE TABLE `ismi`.`appointments` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`id_doctor` INT UNSIGNED NOT NULL,
`id_patient` INT UNSIGNED NOT NULL,
`date` DATETIME NOT NULL,
PRIMARY KEY (`id`),
UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE,
INDEX `id_doctor_idx` (`id_doctor` ASC) VISIBLE,
INDEX `id_patient_idx` (`id_patient` ASC) VISIBLE,
CONSTRAINT `id_doctor`
FOREIGN KEY (`id_doctor`)
REFERENCES `ismi`.`doctors` (`id`)
ON DELETE CASCADE
ON UPDATE CASCADE,
CONSTRAINT `id_patient`
FOREIGN KEY (`id_patient`)
REFERENCES `ismi`.`patients` (`id`)
ON DELETE CASCADE
ON UPDATE CASCADE);
#insert
INSERT INTO `ismi`.`appointments`
(`id_doctor`, `id_patient`, `date`)
VALUES
(%s, %s, %s);
#update
UPDATE `ismi`.`appointments`
SET
`id_doctor` = %s,
`id_patient` = %s,
`date` = %s
WHERE `id` = %s;
#delete
DELETE FROM `ismi`.`appointments`
WHERE `id` = %s;
#select_all
SELECT `appointments`.`id`,
    `appointments`.`id_doctor`,
    `appointments`.`id_patient`,
    `appointments`.`date`
FROM `ismi`.`appointments`;
#select_with_names
SELECT `appointments`.`id`, `doctors`.`name`, `doctors`.`birthdate`, `patients`.`name`, `patients`.`birthdate`, `appointments`.`date`
FROM `ismi`.`appointments`, `ismi`.`doctors`, `ismi`.`patients`
WHERE `appointments`.`id_doctor` = `doctors`.`id` AND `appointments`.`id_patient` = `patients`.`id`;
#select_with_names_find_by_name
SELECT `appointments`.`id`, `doctors`.`name`, `doctors`.`birthdate`, `patients`.`name`, `patients`.`birthdate`, `appointments`.`date`
FROM `ismi`.`appointments`, `ismi`.`doctors`, `ismi`.`patients`
WHERE `appointments`.`id_doctor` = `doctors`.`id` AND `doctors`.`id` IN (SELECT `doctors`.`id` FROM `ismi`.`doctors` WHERE `doctors`.`name` LIKE %s)
AND `appointments`.`id_patient` = `patients`.`id` AND `patients`.`id` IN (SELECT `patients`.`id` FROM `ismi`.`patients` WHERE `patients`.`name` LIKE %s);
