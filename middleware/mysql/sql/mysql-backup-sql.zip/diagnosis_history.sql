#select
SELECT `medical_records`.`id`,
`patients`.`name`,
`medical_records`.`diagnosis`,
`medical_records`.`date`
FROM `ismi`.`medical_records`, `ismi`.`patients`
WHERE `medical_records`.`id_patient` = `patients`.`id`;

#find_by_name_with_names
SELECT `medical_records`.`id`,
`patients`.`name`,
`medical_records`.`diagnosis`,
`medical_records`.`date`
FROM `ismi`.`medical_records`, `ismi`.`patients`
WHERE `patients`.`name` LIKE %s AND `medical_records`.`id_patient` = `patients`.`id`;
