#create
CREATE TABLE `ismi`.`doctors` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`name` VARCHAR(64) NOT NULL,
`birthdate` DATETIME NOT NULL,
`job` VARCHAR(64) NOT NULL,
`wage` INT UNSIGNED ZEROFILL NOT NULL,
`phone` VARCHAR(16) NULL,
PRIMARY KEY (`id`),
UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE,
UNIQUE INDEX `phone_UNIQUE` (`phone` ASC) VISIBLE);

#insert
INSERT INTO `ismi`.`doctors`
(`name`, `birthdate`, `job`, `wage`, `phone`)
VALUES
(%s, %s, %s, %s, %s);

#update
UPDATE `ismi`.`doctors`
SET
`name` = %s,
`birthdate` = %s,
`job` = %s,
`wage` = %s,
`phone` = %s
WHERE `id` = %s;
#delete
DELETE FROM `ismi`.`doctors`
WHERE `id`=%s;

#select_all
SELECT `doctors`.`id`,
    `doctors`.`name`,
    `doctors`.`birthdate`,
    `doctors`.`job`,
    `doctors`.`wage`,
    `doctors`.`phone`
FROM `ismi`.`doctors`;
#find_by_name
SELECT `doctors`.`id`,
    `doctors`.`name`,
    `doctors`.`birthdate`,
    `doctors`.`job`,
    `doctors`.`wage`,
    `doctors`.`phone`
FROM `ismi`.`doctors`
WHERE `doctors`.`name` LIKE %s;

#find_by_name_name_bd_phone
SELECT `doctors`.`name`,
    `doctors`.`birthdate`,
    `doctors`.`phone`
FROM `ismi`.`doctors`
WHERE `doctors`.`name` LIKE %s;

#select_name_bd_phone
SELECT `doctors`.`name`,
    `doctors`.`birthdate`,
    `doctors`.`phone`
FROM `ismi`.`doctors`;
