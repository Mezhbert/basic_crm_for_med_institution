#create
CREATE TABLE `ismi`.`medications` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`title` VARCHAR(64) NOT NULL,
`desc` VARCHAR(256) NOT NULL,
`contraindication` VARCHAR(256) NOT NULL,
PRIMARY KEY (`id`),
UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE,
UNIQUE INDEX `title_UNIQUE` (`title` ASC) VISIBLE);

#insert
INSERT INTO `ismi`.`medications`
(`title`, `desc`, `contraindication`)
VALUES
(%s, %s, %s);

#update
UPDATE `ismi`.`medications`
SET
`title` = %s,
`desc` = %s,
`contraindication` = %s
WHERE `id` = %s;

#delete
DELETE FROM `ismi`.`medications`
WHERE %s;

#select_all
SELECT `medications`.`id`,
`medications`.`title`,
`medications`.`desc`,
`medications`.`contraindication`
FROM `ismi`.`medications`;

#find_by_id
SELECT `medications`.`id`,
    `medications`.`title`,
    `medications`.`desc`,
    `medications`.`contraindication`
FROM `ismi`.`medications`
WHERE `medications`.`id` = %s;

#find_by_name
SELECT `medications`.`id`,
    `medications`.`title`,
    `medications`.`desc`,
    `medications`.`contraindication`
FROM `ismi`.`medications`
WHERE `medications`.`title` LIKE %s;

#find_by_name_without_id
SELECT `medications`.`title`,
    `medications`.`desc`,
    `medications`.`contraindication`
FROM `ismi`.`medications`
WHERE `medications`.`title` LIKE %s;

#select_without_id
SELECT `medications`.`title`,
    `medications`.`desc`,
    `medications`.`contraindication`
FROM `ismi`.`medications`;
