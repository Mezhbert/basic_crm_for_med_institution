#create
CREATE TABLE `ismi`.`medical_records` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`id_patient` INT UNSIGNED NOT NULL,
`date` DATETIME NOT NULL,
`complaints` VARCHAR(128) NULL,
`diagnosis` VARCHAR(64) NULL,
`allergy` VARCHAR(64) NULL,
`treatment` VARCHAR(512) NULL,
`id_prescribed_medication` INT UNSIGNED NULL,
PRIMARY KEY (`id`),
UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE,
INDEX `mr_id_patient_idx` (`id_patient` ASC) VISIBLE,
INDEX `mr_id_prescribed medication_idx` (`id_prescribed_medication` ASC) VISIBLE,
CONSTRAINT `mr_id_patient`
FOREIGN KEY (`id_patient`)
REFERENCES `ismi`.`patients` (`id`)
ON DELETE CASCADE
ON UPDATE CASCADE,
CONSTRAINT `mr_id_prescribed medication`
FOREIGN KEY (`id_prescribed_medication`)
REFERENCES `ismi`.`medications` (`id`)
ON DELETE CASCADE
ON UPDATE CASCADE);

#insert
INSERT INTO `ismi`.`medical_records`
(`id_patient`, `date`, `complaints`, `diagnosis`, `allergy`, `treatment`, `id_prescribed_medication`)
VALUES
(%s, %s, %s, %s, %s, %s, %s);
#update
UPDATE `ismi`.`medical_records`
SET
`id_patient` = %s,
`date` = %s,
`complaints` = %s,
`diagnosis` = %s,
`allergy` = %s,
`treatment` = %s,
`id_prescribed_medication` = %s
WHERE `id` = %s;
#delete
DELETE FROM `ismi`.`medical_records`
WHERE `id` = %s;
#select_all
SELECT `medical_records`.`id`,
    `medical_records`.`id_patient`,
    `medical_records`.`date`,
    `medical_records`.`complaints`,
    `medical_records`.`diagnosis`,
    `medical_records`.`allergy`,
    `medical_records`.`treatment`,
    `medical_records`.`id_prescribed_medication`
FROM `ismi`.`medical_records`;
#select_with_names
SELECT `medical_records`.`id`,
`patients`.`name`,
`medical_records`.`date`,
`medical_records`.`complaints`,
`medical_records`.`diagnosis`,
`medical_records`.`allergy`,
`medical_records`.`treatment`,
`medications`.`title`
FROM `ismi`.`medical_records`, `ismi`.`patients`, `ismi`.`medications`
WHERE `medical_records`.`id_patient` = `patients`.`id` AND `medical_records`.`id_prescribed_medication` = `medications`.`id`;
#find_by_patient_id
SELECT `medical_records`.`id`,
`medical_records`.`date`,
`medical_records`.`complaints`,
`medical_records`.`diagnosis`,
`medical_records`.`allergy`,
`medical_records`.`treatment`,
`medications`.`title`
FROM `ismi`.`medical_records`, `ismi`.`medications`
WHERE `medical_records`.`id_patient` = %s AND `medical_records`.`id_prescribed_medication` = `medications`.`id`;

#find_by_medication_id
SELECT `medical_records`.`id`,
`patients`.`name`,
`medical_records`.`date`,
`medical_records`.`complaints`,
`medical_records`.`diagnosis`,
`medical_records`.`allergy`,
`medical_records`.`treatment`
FROM `ismi`.`medical_records`, `ismi`.`patients`
WHERE `medical_records`.`id_prescribed_medication` = %s AND `medical_records`.`id_patient` = `patients`.`id`;

#find_by_name_with_names
SELECT `medical_records`.`id`,
    `patients`.`name`,
    `medical_records`.`date`,
    `medical_records`.`complaints`,
    `medical_records`.`diagnosis`,
    `medical_records`.`allergy`,
    `medical_records`.`treatment`,
    `medications`.`title`
FROM `ismi`.`medical_records`, `ismi`.`patients`, `ismi`.`medications`
WHERE `patients`.`name` LIKE %s AND `medical_records`.`id_patient` = `patients`.`id` AND `medical_records`.`id_prescribed_medication` = `medications`.`id`;
