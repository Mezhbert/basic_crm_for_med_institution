#create
CREATE TABLE `ismi`.`gender_types` (
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`type` VARCHAR(8) NOT NULL,
PRIMARY KEY (`id`),
UNIQUE INDEX `id_UNIQUE` (`id` ASC) VISIBLE,
UNIQUE INDEX `type_UNIQUE` (`type` ASC) VISIBLE);

#insert
INSERT INTO `ismi`.`gender_types`
(`type`)
VALUES
(%s);

#select
SELECT `gender_types`.`id`,
    `gender_types`.`type`
FROM `ismi`.`gender_types`
ORDER BY `id`;
